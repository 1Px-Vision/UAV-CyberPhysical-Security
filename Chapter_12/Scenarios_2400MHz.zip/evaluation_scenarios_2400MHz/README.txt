2400 MHz SIMULATION EVALUATION SCENARIOS
=======================================
Import ONE JSON at a time into Connected Scenario in rf_learning_studio_v32.py.
Enable builder integration. Select receiver carrier 2400 MHz, receiver bandwidth
125 kHz, and desired received reference -70 dBm (use the dashboard link budget
to establish this desired signal level). For an illustrative free-space reference:
TX 0 dBm, TX/RX gains 0 dBi, distance about 31.5 m, path-loss exponent 2.
Confirm the displayed desired received power before comparing J/S.
Countermeasures are chosen in the dashboard, not in these JSON files.
Use No countermeasure first, then compare at the same frame and settings.

POWER CONVENTION
power_dbm is the branch interference reference at the RF stage, not transmitter
output power. Source strengths sum to 1; noise_floor is -100 dBm. With desired
received signal -70 dBm, nominal active interference J/S equals power_dbm + 70.
Actual waveform J/S can differ slightly for additive correlated components.
Gated spot cases use ON-window power; quiet frames have no interference.
Pulsed and random waveform strategies use frame-average J/S normalization;
lower occupancy increases instantaneous burst power. These conventions differ.
Strength is a linear power fraction, not dBm. SUM gain 1 adds contributions;
it does not multiply waveforms or apply a gate. No extra antenna gains or path
attenuation are added after the received-power RF stage.

MODEL LIMITS
2400 MHz is the RF metadata center. Center/span in waveform params are kHz
baseband offsets/bandwidth within a 200 ksample/s toy model, not full Wi-Fi RF
bandwidth. DWM3000 UWB ranging is not a 2400 MHz receiver; these cases represent
a separate 2.4 GHz D2D link/coexistence evaluation, not its UWB channel.
Continuous is modeled as a timing property of spot/sweep, not an added
continuous-strategy waveform (which would change their spectrum).
Reactive case is additive: continuous spot and tone plus the existing reactive
noise/tone branch. The graph schema cannot gate the entire combined waveform
from measured target packet activity. Adaptive is frame-varying, not closed-loop.
Friendly random schedule is a fixed illustrative irregular frame schedule; it does not draw new random windows on import.
PDR is model-estimated; RF DoS/failsafe outcomes are not guaranteed by presets.
These JSONs are simulation scenarios; existing hardware TX does not transmit
simulated attack waveforms.

CASES

D2D_Narrow_2400MHz.json
  Interference reference: -70 dBm; nominal active J/S: +0 dB.
  Continuous spot noise; continuous describes timing, not an additional noise source.

D2D_Transient_Resilience_2400MHz.json
  Interference reference: -67 dBm; nominal active J/S: +3 dB.
  The pulsed model gates Gaussian noise: implements Noise + Pulsed without adding a continuous noise branch.

D2D_Unpredictable_Exposure_2400MHz.json
  Interference reference: -67 dBm; nominal active J/S: +3 dB.
  Random model gates Gaussian noise in randomized 1 ms windows.

D2D_Channel_Diversity_2400MHz.json
  Interference reference: -67 dBm; nominal active J/S: +3 dB.
  Continuous sweep. Channel diversity mitigation must be selected in the dashboard; JSON does not activate hopping.

RF_DoS_Resilience_2400MHz.json
  Interference reference: -60 dBm; nominal active J/S: +10 dB.
  Additive three-source exposure; barrage is the simulator multi-tone approximation. No guaranteed DoS outcome.

Activity_Dependent_Interference_2400MHz.json
  Interference reference: -65 dBm; nominal active J/S: +5 dB.
  Additive spot + tone + reactive branches. ONLY the reactive branch is activity-gated; it uses the existing envelope-driven noise/tone model and is not band-limited spot noise.

Friendly_Spot_Intermittent_2400MHz.json
  Interference reference: -76 dBm; nominal active J/S: -6 dB.
  Spot noise gated at frame level: start 10, duration 10, period 30. Independent of target activity.

Friendly_Spot_Random_2400MHz.json
  Interference reference: -76 dBm; nominal active J/S: -6 dB.
  Spot noise gated by a reproducible irregular frame schedule. Fixed realization generated with seed 42; importing does not regenerate it.

Friendly_Spot_Continuous_2400MHz.json
  Interference reference: -76 dBm; nominal active J/S: -6 dB.
  Continuous spot noise reference for friendly coexistence; not actual modulated friendly traffic.

Failsafe_2400MHz.json
  Interference reference: -58 dBm; nominal active J/S: +12 dB.
  Existing failsafe interference model. Observe dashboard safety transitions; transition thresholds are not set by graph JSON.

Adaptive_Defense_2400MHz.json
  Interference reference: -65 dBm; nominal active J/S: +5 dB.
  Additive frame-varying adaptive model + pulsed noise. Select defense separately; existing adaptive model is not closed-loop.
