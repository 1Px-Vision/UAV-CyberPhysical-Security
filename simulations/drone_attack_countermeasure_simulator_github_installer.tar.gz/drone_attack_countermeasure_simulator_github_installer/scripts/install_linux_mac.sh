#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "[install] Creating virtual environment in .venv"
"$PYTHON_BIN" -m venv .venv

echo "[install] Activating virtual environment"
# shellcheck disable=SC1091
source .venv/bin/activate

echo "[install] Upgrading pip"
python -m pip install --upgrade pip

echo "[install] Installing simulator in editable mode"
python -m pip install -e .

echo "[install] Done. Run: bash scripts/run_linux_mac.sh"
