#!/usr/bin/env bash
set -euo pipefail

if [ ! -d ".venv" ]; then
  echo "Virtual environment not found. Run: bash scripts/install_linux_mac.sh"
  exit 1
fi

# shellcheck disable=SC1091
source .venv/bin/activate

echo "Starting simulator at http://127.0.0.1:8050"
drone-attack-sim --host 127.0.0.1 --port 8050
