$ErrorActionPreference = "Stop"

if (-Not (Test-Path ".\.venv\Scripts\Activate.ps1")) {
    Write-Host "Virtual environment not found. Run: powershell -ExecutionPolicy Bypass -File scripts/install_windows.ps1"
    exit 1
}

. .\.venv\Scripts\Activate.ps1
Write-Host "Starting simulator at http://127.0.0.1:8050"
drone-attack-sim --host 127.0.0.1 --port 8050
