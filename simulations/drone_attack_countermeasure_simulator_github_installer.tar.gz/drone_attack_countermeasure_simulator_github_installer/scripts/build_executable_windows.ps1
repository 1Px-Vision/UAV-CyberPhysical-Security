$ErrorActionPreference = "Stop"
if (Test-Path ".\.venv\Scripts\Activate.ps1") { . .\.venv\Scripts\Activate.ps1 }
python -m pip install -r requirements-dev.txt
pyinstaller --onefile --name drone-attack-sim src/drone_attack_countermeasure_simulator/__main__.py
Write-Host "Executable created in dist/"
