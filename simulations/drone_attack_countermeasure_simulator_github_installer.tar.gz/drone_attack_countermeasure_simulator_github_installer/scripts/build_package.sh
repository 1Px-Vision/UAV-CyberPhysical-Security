#!/usr/bin/env bash
set -euo pipefail
source .venv/bin/activate 2>/dev/null || true
python -m pip install -r requirements-dev.txt
python -m build
echo "Package created in dist/"
