#!/usr/bin/env bash
set -euo pipefail
source .venv/bin/activate 2>/dev/null || true
python -m pip install -r requirements-dev.txt
pyinstaller --onefile --name drone-attack-sim src/drone_attack_countermeasure_simulator/__main__.py
echo "Executable created in dist/"
