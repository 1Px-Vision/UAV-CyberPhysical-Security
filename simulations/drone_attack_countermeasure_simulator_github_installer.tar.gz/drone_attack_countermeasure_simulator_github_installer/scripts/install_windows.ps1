$ErrorActionPreference = "Stop"

Write-Host "[install] Creating virtual environment in .venv"
py -3 -m venv .venv

Write-Host "[install] Activating virtual environment"
. .\.venv\Scripts\Activate.ps1

Write-Host "[install] Upgrading pip"
python -m pip install --upgrade pip

Write-Host "[install] Installing simulator in editable mode"
python -m pip install -e .

Write-Host "[install] Done. Run: powershell -ExecutionPolicy Bypass -File scripts/run_windows.ps1"
