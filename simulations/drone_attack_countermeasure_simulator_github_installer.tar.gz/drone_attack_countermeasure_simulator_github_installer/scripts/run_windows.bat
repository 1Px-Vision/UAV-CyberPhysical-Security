@echo off
IF NOT EXIST .venv\Scripts\activate.bat (
  echo Virtual environment not found. Run scripts\install_windows.ps1 first.
  exit /b 1
)
call .venv\Scripts\activate.bat
echo Starting simulator at http://127.0.0.1:8050
drone-attack-sim --host 127.0.0.1 --port 8050
