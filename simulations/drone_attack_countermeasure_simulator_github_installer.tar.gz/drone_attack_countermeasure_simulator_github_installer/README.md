# Drone Attack and Countermeasure Educational Simulator

An interactive Dash dashboard for **safe, abstract, baseband-only education** about UAV RF-link degradation, GPS-spoofing symptoms, and defensive countermeasure concepts. The simulator is designed for book demonstrations, classroom use, and defensive research visualization.

> Safety scope: this project does **not** transmit RF energy, control real drones, provide operational jamming procedures, or include hardware instructions. All signals are normalized numerical waveforms for visualization.

## Main features

- Tabbed simulation controls for mission, RF link, geometry/channel, attack waveform, and navigation.
- Start, Stop, and Reset buttons for live simulation playback.
- Help Mode with emergent explanation windows for each control group.
- Educational attack/anomaly models: noise, tone, sweep, barrage, pulsed, continuous, intermittent, reactive, adaptive, failsafe-triggering, and GPS spoofing.
- Countermeasure models: spectral notch filtering, hopping/channel diversity, GPS/VIO/TDoA sensor-fusion gating, adaptive safe mode, and combined defense stack.
- Live scopes for waveform, spectrum, waterfall, navigation, metrics, RF link budget, and summary.

## Quick install

### Linux / macOS

```bash
git clone https://github.com/<your-user>/drone-attack-countermeasure-simulator.git
cd drone-attack-countermeasure-simulator
bash scripts/install_linux_mac.sh
bash scripts/run_linux_mac.sh
```

### Windows PowerShell

```powershell
git clone https://github.com/<your-user>/drone-attack-countermeasure-simulator.git
cd drone-attack-countermeasure-simulator
powershell -ExecutionPolicy Bypass -File scripts/install_windows.ps1
powershell -ExecutionPolicy Bypass -File scripts/run_windows.ps1
```

Then open: <http://127.0.0.1:8050>

## Manual install

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
python -m pip install -e .
drone-attack-sim
```

You can also run the module directly:

```bash
python -m drone_attack_countermeasure_simulator --host 127.0.0.1 --port 8050
```

## Control parameters

The simulator includes adjustable controls for:

- **Mission:** attack/anomaly type, countermeasure type, update interval.
- **RF link:** carrier frequency, signal bandwidth, legitimate TX power, attack-source power, TX/RX antenna gain, attack antenna gain.
- **Geometry/channel:** drone link distance, attack-source distance, path-loss exponent, receiver noise figure, background SNR limit.
- **Attack waveform:** J/S trim, jammer center offset, sweep/barrage span, duty cycle.
- **Navigation:** GPS-spoofing maximum bias and fusion/safe-mode behavior.

These controls affect the educational link budget, received signal quality, J/S ratio, packet-delivery ratio, GPS innovation, localization error, and mission safety state.

## Attack types

The dashboard models the following abstract attack/anomaly categories:

- Noise jamming
- Tone jamming
- Sweep jamming
- Barrage jamming
- Pulsed jamming
- Continuous jamming
- Intermittent jamming
- Reactive jamming
- Adaptive jamming
- Failsafe-triggering attacks
- GPS spoofing

## Countermeasures

The simulator demonstrates layered defensive concepts:

- Spectral notch filtering
- Hopping / channel diversity
- GPS/VIO/TDoA sensor-fusion gating
- Adaptive link manager + safe mode
- Combined defense stack

## Build a Python package

```bash
python -m pip install -r requirements-dev.txt
python -m build
```

The package files will be created in `dist/`.

## Optional: build a local executable

```bash
python -m pip install -r requirements-dev.txt
pyinstaller --onefile --name drone-attack-sim src/drone_attack_countermeasure_simulator/__main__.py
```

The executable will be created in `dist/`.

## Suggested GitHub upload

```bash
git init
git add .
git commit -m "Initial educational drone attack simulator"
git branch -M main
git remote add origin https://github.com/<your-user>/drone-attack-countermeasure-simulator.git
git push -u origin main
```

## Project structure

```text
drone-attack-countermeasure-simulator/
├── src/drone_attack_countermeasure_simulator/
│   ├── __init__.py
│   ├── __main__.py
│   └── app.py
├── scripts/
│   ├── install_linux_mac.sh
│   ├── install_windows.ps1
│   ├── run_linux_mac.sh
│   └── run_windows.ps1
├── requirements.txt
├── requirements-dev.txt
├── pyproject.toml
├── README.md
├── SAFETY.md
├── LICENSE
└── .gitignore
```
