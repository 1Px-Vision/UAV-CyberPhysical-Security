# Safety and Intended Use

This simulator is intended for education, book illustrations, and defensive analysis only.

The project uses normalized numerical baseband waveforms and abstract mission models. It does not transmit RF energy, interface with RF hardware, control drones, or provide operational attack procedures.

Appropriate uses include:

- Explaining RF-link degradation symptoms in a classroom or book chapter.
- Demonstrating defensive ideas such as filtering, channel diversity, sensor-fusion gating, and safe-mode logic.
- Comparing qualitative effects of different abstract anomaly models on packet delivery, navigation error, and mission safety state.

Do not use this software to interfere with real communications, navigation systems, aircraft, UAVs, emergency services, or any other real-world systems.
