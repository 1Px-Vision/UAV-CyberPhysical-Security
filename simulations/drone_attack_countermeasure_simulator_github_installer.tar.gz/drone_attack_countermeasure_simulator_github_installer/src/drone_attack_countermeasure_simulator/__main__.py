from __future__ import annotations

import argparse

from .app import app


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the Drone Attack and Countermeasure Educational Simulator."
    )
    parser.add_argument("--host", default="127.0.0.1", help="Host interface. Default: 127.0.0.1")
    parser.add_argument("--port", default=8050, type=int, help="Web server port. Default: 8050")
    parser.add_argument("--debug", action="store_true", help="Enable Dash debug mode for development.")
    args = parser.parse_args()
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
