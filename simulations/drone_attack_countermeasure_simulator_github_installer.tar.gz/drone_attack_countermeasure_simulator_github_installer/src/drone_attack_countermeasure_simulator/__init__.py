"""Drone Attack and Countermeasure Educational Simulator."""

__version__ = "1.0.0"
