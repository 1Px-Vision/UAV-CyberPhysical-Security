"""
Drone Attack and Countermeasure Educational Simulator
=====================================================

Purpose
-------
This dashboard is a SAFE, abstract, baseband-only simulator for education,
book illustrations, and defensive analysis. It does NOT transmit RF energy,
control real drones, provide real-world jamming parameters, or include any
hardware instructions. All signals are normalized numerical waveforms.

Simulated topics
----------------
- Jamming waveform visualization
- Noise, tone, sweep, barrage, pulsed, continuous, intermittent, reactive,
  adaptive, and failsafe-triggering attacks
- GPS spoofing as a navigation-bias model
- Defensive countermeasures: spectral notching, hopping diversity, sensor-fusion
  gating, adaptive safe mode, and combined defense

Run
---
    pip install dash plotly numpy
    python -m drone_attack_countermeasure_simulator

Open http://127.0.0.1:8050 in a browser.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash import Dash, dcc, html, Input, Output, State, callback_context, ALL


# -----------------------------------------------------------------------------
# Global simulation constants. These are normalized educational values only.
# -----------------------------------------------------------------------------
FS = 200_000.0
N = 4096
N_STEPS = 90
SAFE_RANDOM_SEED = 42

ATTACK_TYPES = {
    "none": "No attack / nominal link",
    "noise": "Noise jamming",
    "tone": "Tone jamming",
    "sweep": "Sweep jamming",
    "barrage": "Barrage jamming",
    "pulsed": "Pulsed jamming",
    "continuous": "Continuous jamming",
    "intermittent": "Intermittent jamming",
    "reactive": "Reactive jamming",
    "adaptive": "Adaptive jamming",
    "failsafe": "Failsafe-triggering attack",
    "gps_spoofing": "GPS spoofing",
}

COUNTERMEASURES = {
    "none": "No countermeasure",
    "notch": "Spectral notch filtering",
    "hopping": "Hopping / channel diversity",
    "fusion_gate": "GPS/VIO/TDoA sensor-fusion gating",
    "adaptive_safe": "Adaptive link manager + safe mode",
    "full_defense": "Combined defense stack",
}

ATTACK_SYMPTOMS = {
    "none": "Nominal RSSI, high correlation peak, stable position estimate.",
    "noise": "Raised noise floor, reduced correlation peak, lower packet delivery ratio.",
    "tone": "Narrowband spectral spike that can reduce receiver dynamic range.",
    "sweep": "Time-varying narrowband interference visible in the waterfall.",
    "barrage": "Multiple simultaneous spectral lines occupying several channels.",
    "pulsed": "Short high-energy bursts that cause intermittent packet loss.",
    "continuous": "Persistent interference that raises the noise floor across the link.",
    "intermittent": "Communication alternates between usable and degraded windows.",
    "reactive": "Interference appears mainly when the legitimate signal is active.",
    "adaptive": "The interference pattern changes with time and partially evades static filters.",
    "failsafe": "Link degradation and navigation inconsistency can force hover or return-home.",
    "gps_spoofing": "The GPS-like position drifts away from VIO/TDoA and the true trajectory.",
}

COUNTERMEASURE_NOTES = {
    "none": "No protection is applied; this shows the raw effect of the selected attack.",
    "notch": "Useful against tone and barrage-like interference; less effective against wideband noise.",
    "hopping": "Models channel diversity by reducing jammer coupling in the protected link.",
    "fusion_gate": "Rejects inconsistent GPS-like data and trusts VIO/TDoA when spoofing is detected.",
    "adaptive_safe": "Slows the mission, enables store-carry-forward behavior, and triggers safe navigation states.",
    "full_defense": "Combines hopping diversity, spectral suppression, spoofing detection, and safe-mode logic.",
}


# -----------------------------------------------------------------------------
# Data structures
# -----------------------------------------------------------------------------
@dataclass
class LinkBudget:
    carrier_mhz: float
    signal_bandwidth_khz: float
    tx_power_dbm: float
    jammer_power_dbm: float
    tx_gain_dbi: float
    rx_gain_dbi: float
    jammer_gain_dbi: float
    link_distance_m: float
    attacker_distance_m: float
    path_loss_exponent: float
    noise_figure_db: float
    legitimate_path_loss_db: float
    jammer_path_loss_db: float
    legitimate_rx_dbm: float
    jammer_rx_dbm: float
    noise_floor_dbm: float
    link_budget_snr_db: float
    link_budget_jsr_db: float
    effective_jsr_db: float


@dataclass
class RFResult:
    tx: np.ndarray
    jammer: np.ndarray
    raw_rx: np.ndarray
    protected_rx: np.ndarray
    t_ms: np.ndarray
    effective_snr_db: float
    raw_jsr_db: float
    pdr: float
    correlation_quality: float
    link_state: str
    dropout_factor: float
    link_budget: LinkBudget


@dataclass
class NavResult:
    true_path: np.ndarray
    gps_path: np.ndarray
    vio_path: np.ndarray
    tdoa_path: np.ndarray
    fused_path: np.ndarray
    current_step: int
    gps_innovation_m: float
    localization_error_m: float
    mission_state: str
    spoof_detected: bool
    safe_mode: bool


@dataclass
class SimulationResult:
    rf: RFResult
    nav: NavResult
    attack_type: str
    countermeasure: str
    live_index: int
    status: Dict[str, str]


# -----------------------------------------------------------------------------
# Utility functions
# -----------------------------------------------------------------------------
def db_to_linear(db_value: float) -> float:
    return 10.0 ** (db_value / 10.0)


def safe_power(x: np.ndarray) -> float:
    return float(np.mean(np.square(np.asarray(x, dtype=float))) + 1e-12)


def normalize(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    peak = float(np.max(np.abs(x)) + 1e-12)
    return x / peak


def moving_average(x: np.ndarray, win: int) -> np.ndarray:
    win = max(3, int(win))
    kernel = np.ones(win, dtype=float) / win
    pad_left = win // 2
    pad_right = win - 1 - pad_left
    padded = np.pad(x, (pad_left, pad_right), mode="edge")
    return np.convolve(padded, kernel, mode="valid")


def smoothstep(u: float) -> float:
    u = float(np.clip(u, 0.0, 1.0))
    return u * u * (3.0 - 2.0 * u)


def sigmoid(x: float) -> float:
    return float(1.0 / (1.0 + math.exp(-x)))


def path_loss_db(carrier_mhz: float, distance_m: float, path_loss_exponent: float) -> float:
    """Educational log-distance path-loss model referenced to 1 meter."""
    carrier_mhz = max(1.0, float(carrier_mhz))
    distance_m = max(1.0, float(distance_m))
    n = float(np.clip(path_loss_exponent, 1.6, 4.5))
    # Free-space path loss at 1 m: 32.44 + 20log10(f_MHz) + 20log10(0.001 km).
    fspl_1m_db = 32.44 + 20.0 * math.log10(carrier_mhz) - 60.0
    return float(fspl_1m_db + 10.0 * n * math.log10(distance_m))


def compute_link_budget(
    carrier_mhz: float,
    signal_bandwidth_khz: float,
    tx_power_dbm: float,
    jammer_power_dbm: float,
    tx_gain_dbi: float,
    rx_gain_dbi: float,
    jammer_gain_dbi: float,
    link_distance_m: float,
    attacker_distance_m: float,
    path_loss_exponent: float,
    noise_figure_db: float,
    jsr_trim_db: float,
) -> LinkBudget:
    """Compute an abstract RF-link budget used to drive the dashboard metrics."""
    bandwidth_hz = max(1.0, float(signal_bandwidth_khz) * 1000.0)
    legit_pl = path_loss_db(carrier_mhz, link_distance_m, path_loss_exponent)
    jammer_pl = path_loss_db(carrier_mhz, attacker_distance_m, path_loss_exponent)

    legitimate_rx_dbm = float(tx_power_dbm + tx_gain_dbi + rx_gain_dbi - legit_pl)
    jammer_rx_dbm = float(jammer_power_dbm + jammer_gain_dbi + rx_gain_dbi - jammer_pl)
    noise_floor_dbm = float(-174.0 + 10.0 * math.log10(bandwidth_hz) + noise_figure_db)
    link_budget_snr_db = legitimate_rx_dbm - noise_floor_dbm
    link_budget_jsr_db = jammer_rx_dbm - legitimate_rx_dbm
    effective_jsr_db = link_budget_jsr_db + float(jsr_trim_db)

    return LinkBudget(
        carrier_mhz=float(carrier_mhz),
        signal_bandwidth_khz=float(signal_bandwidth_khz),
        tx_power_dbm=float(tx_power_dbm),
        jammer_power_dbm=float(jammer_power_dbm),
        tx_gain_dbi=float(tx_gain_dbi),
        rx_gain_dbi=float(rx_gain_dbi),
        jammer_gain_dbi=float(jammer_gain_dbi),
        link_distance_m=float(link_distance_m),
        attacker_distance_m=float(attacker_distance_m),
        path_loss_exponent=float(path_loss_exponent),
        noise_figure_db=float(noise_figure_db),
        legitimate_path_loss_db=legit_pl,
        jammer_path_loss_db=jammer_pl,
        legitimate_rx_dbm=legitimate_rx_dbm,
        jammer_rx_dbm=jammer_rx_dbm,
        noise_floor_dbm=noise_floor_dbm,
        link_budget_snr_db=float(link_budget_snr_db),
        link_budget_jsr_db=float(link_budget_jsr_db),
        effective_jsr_db=float(effective_jsr_db),
    )


# -----------------------------------------------------------------------------
# Baseband signal and attack models
# -----------------------------------------------------------------------------
def generate_pn_bpsk(n: int, live_index: int) -> np.ndarray:
    """Generate a simple BPSK-like spread-spectrum educational signal."""
    rng = np.random.default_rng(SAFE_RANDOM_SEED)
    chips = rng.choice([-1.0, 1.0], size=512)
    preamble = np.array([1, 1, 1, -1, 1, -1, -1, 1] * 8, dtype=float)
    symbol_stream = np.concatenate([preamble, chips])
    samples = np.repeat(symbol_stream, 6)
    repeated = np.resize(samples, n + 512)

    # Gentle motion of the visualization window.
    shift = int((live_index * 17) % 512)
    tx = repeated[shift:shift + n]

    # Small baseband shaping to make the scope less ideal.
    tx = moving_average(tx, 3)
    return normalize(tx)


def reactive_gate(tx: np.ndarray, duty_cycle: float) -> np.ndarray:
    """Gate that activates only when the legitimate signal envelope is present."""
    envelope = moving_average(np.abs(tx), 64)
    threshold = np.quantile(envelope, 1.0 - np.clip(duty_cycle, 0.05, 0.95))
    gate = (envelope >= threshold).astype(float)
    return moving_average(gate, 11)


def square_gate(n: int, fs: float, live_index: int, duty_cycle: float, period_ms: float) -> np.ndarray:
    t = np.arange(n, dtype=float) / fs
    phase = (t + 0.003 * live_index) % (period_ms / 1000.0)
    return (phase < (period_ms / 1000.0) * duty_cycle).astype(float)


def jammer_waveform(
    attack_type: str,
    tx: np.ndarray,
    fs: float,
    jsr_db: float,
    duty_cycle: float,
    live_index: int,
    rng: np.random.Generator,
    jammer_center_khz: float = 20.0,
    sweep_span_khz: float = 80.0,
) -> Tuple[np.ndarray, float]:
    """
    Return a normalized jammer waveform and an additional dropout factor.

    The waveform is an abstract numerical sequence. Frequencies are normalized
    baseband offsets, not real radio operating frequencies.
    """
    n = len(tx)
    t = np.arange(n, dtype=float) / fs
    duty_cycle = float(np.clip(duty_cycle, 0.05, 1.0))
    phase = 0.031 * live_index
    nyquist_margin_hz = 0.45 * fs
    center_hz = float(np.clip(abs(jammer_center_khz) * 1000.0, 500.0, nyquist_margin_hz))
    span_hz = float(np.clip(abs(sweep_span_khz) * 1000.0, 1000.0, 0.80 * fs))

    if attack_type == "none":
        unit = np.zeros(n)
        dropout = 0.0
    elif attack_type == "noise":
        unit = rng.normal(0.0, 1.0, n)
        dropout = 0.05
    elif attack_type == "tone":
        f0 = center_hz
        unit = np.sin(2.0 * math.pi * f0 * t + phase)
        dropout = 0.08
    elif attack_type == "sweep":
        f0 = float(np.clip(center_hz - 0.5 * span_hz, 500.0, nyquist_margin_hz))
        f1 = float(np.clip(center_hz + 0.5 * span_hz, 1000.0, nyquist_margin_hz))
        if f1 <= f0:
            f0, f1 = 1000.0, nyquist_margin_hz
        sweep_period = 0.030
        local_t = (t + 0.002 * live_index) % sweep_period
        k = (f1 - f0) / sweep_period
        unit = np.sin(2.0 * math.pi * (f0 * local_t + 0.5 * k * local_t * local_t))
        dropout = 0.12
    elif attack_type == "barrage":
        offsets = np.linspace(-0.45, 0.45, 5) * span_hz
        freqs = np.clip(center_hz + offsets, 500.0, nyquist_margin_hz)
        unit = np.zeros(n)
        for i, f in enumerate(freqs):
            unit += np.sin(2.0 * math.pi * f * t + phase * (i + 1))
        unit /= math.sqrt(len(freqs))
        dropout = 0.18
    elif attack_type == "pulsed":
        gate = square_gate(n, fs, live_index, duty_cycle, period_ms=6.0)
        unit = gate * rng.normal(0.0, 1.0, n)
        dropout = 0.25 * duty_cycle
    elif attack_type == "continuous":
        noise = rng.normal(0.0, 0.7, n)
        tone = 0.5 * np.sin(2.0 * math.pi * center_hz * t + phase)
        unit = noise + tone
        dropout = 0.22
    elif attack_type == "intermittent":
        gate = square_gate(n, fs, live_index, duty_cycle, period_ms=24.0)
        unit = gate * rng.normal(0.0, 1.0, n)
        dropout = 0.35 * duty_cycle
    elif attack_type == "reactive":
        gate = reactive_gate(tx, duty_cycle)
        unit = gate * (0.65 * rng.normal(0.0, 1.0, n) + 0.35 * np.sin(2.0 * math.pi * center_hz * t + phase))
        dropout = 0.30 * duty_cycle
    elif attack_type == "adaptive":
        # The pattern changes with the live frame: sometimes narrowband,
        # sometimes wideband, sometimes pulsed. This is only a toy model.
        alpha = 0.5 + 0.5 * math.sin(0.21 * live_index)
        gate = square_gate(n, fs, live_index, 0.35 + 0.45 * alpha, period_ms=10.0)
        adaptive_center = float(np.clip(center_hz * (0.65 + 0.70 * alpha), 500.0, nyquist_margin_hz))
        sweep = np.sin(2.0 * math.pi * adaptive_center * t + 2.0 * np.pi * span_hz * t * t)
        noise = rng.normal(0.0, 1.0, n)
        tone = np.sin(2.0 * math.pi * float(np.clip(center_hz + 0.25 * span_hz * alpha, 500.0, nyquist_margin_hz)) * t + phase)
        unit = 0.35 * noise + 0.35 * sweep + 0.30 * gate * tone
        dropout = 0.30
    elif attack_type == "failsafe":
        gate = square_gate(n, fs, live_index, max(0.45, duty_cycle), period_ms=9.0)
        pulse = gate * rng.normal(0.0, 1.0, n)
        tone = 0.4 * np.sin(2.0 * math.pi * center_hz * t + phase)
        unit = pulse + tone
        dropout = 0.50
    elif attack_type == "gps_spoofing":
        # Spoofing is mainly represented in the navigation layer. The RF layer
        # includes a weak deceptive component only for visualization.
        unit = 0.25 * np.sin(2.0 * math.pi * center_hz * t + phase)
        dropout = 0.05
    else:
        unit = np.zeros(n)
        dropout = 0.0

    unit = normalize(unit) if np.any(np.abs(unit) > 1e-12) else unit
    signal_rms = math.sqrt(safe_power(tx))
    jammer_rms = signal_rms * math.sqrt(db_to_linear(jsr_db))
    return jammer_rms * unit, float(np.clip(dropout, 0.0, 0.9))


def spectral_notch_filter(x: np.ndarray, fs: float, n_peaks: int = 4, half_width_bins: int = 4) -> np.ndarray:
    """Simple educational FFT notch filter for narrowband interference."""
    x = np.asarray(x, dtype=float)
    n = len(x)
    X = np.fft.fft(x)
    mag = np.abs(X)

    # Ignore DC and mirrored edges when searching for dominant narrowband peaks.
    ignore = max(5, n // 80)
    mag[:ignore] = 0.0
    mag[-ignore:] = 0.0

    peak_indices = np.argsort(mag)[-n_peaks:]
    mask = np.ones(n, dtype=float)
    for idx in peak_indices:
        for k in range(-half_width_bins, half_width_bins + 1):
            mask[(idx + k) % n] = 0.08
            mask[(-idx + k) % n] = 0.08

    y = np.real(np.fft.ifft(X * mask))
    return y


def residual_jammer_factor(attack_type: str, countermeasure: str) -> float:
    """Toy-model reduction factor for protected signal processing."""
    if countermeasure == "none":
        return 1.0
    if countermeasure == "notch":
        return {
            "tone": 0.18,
            "barrage": 0.35,
            "sweep": 0.55,
            "adaptive": 0.70,
            "noise": 0.92,
            "continuous": 0.75,
            "pulsed": 0.80,
            "intermittent": 0.80,
            "reactive": 0.75,
            "failsafe": 0.72,
            "gps_spoofing": 0.90,
        }.get(attack_type, 1.0)
    if countermeasure == "hopping":
        return {
            "tone": 0.22,
            "sweep": 0.35,
            "barrage": 0.50,
            "noise": 0.70,
            "continuous": 0.55,
            "pulsed": 0.55,
            "intermittent": 0.45,
            "reactive": 0.60,
            "adaptive": 0.72,
            "failsafe": 0.60,
            "gps_spoofing": 0.85,
        }.get(attack_type, 1.0)
    if countermeasure == "fusion_gate":
        return 0.95
    if countermeasure == "adaptive_safe":
        return {
            "noise": 0.70,
            "tone": 0.50,
            "sweep": 0.55,
            "barrage": 0.65,
            "pulsed": 0.50,
            "continuous": 0.65,
            "intermittent": 0.45,
            "reactive": 0.60,
            "adaptive": 0.75,
            "failsafe": 0.55,
            "gps_spoofing": 0.85,
        }.get(attack_type, 1.0)
    if countermeasure == "full_defense":
        return {
            "noise": 0.55,
            "tone": 0.12,
            "sweep": 0.22,
            "barrage": 0.32,
            "pulsed": 0.35,
            "continuous": 0.42,
            "intermittent": 0.30,
            "reactive": 0.42,
            "adaptive": 0.58,
            "failsafe": 0.40,
            "gps_spoofing": 0.65,
        }.get(attack_type, 1.0)
    return 1.0


def correlation_quality(rx: np.ndarray, tx: np.ndarray) -> float:
    ref_len = min(800, len(tx) // 3)
    ref = tx[:ref_len]
    window = rx[:ref_len + 400]
    corr = np.correlate(window, ref, mode="valid")
    a = np.abs(corr)
    peak = float(np.max(a) + 1e-12)
    floor = float(np.median(a) + 1.4826 * np.median(np.abs(a - np.median(a))) + 1e-12)
    ratio = peak / floor
    return float(np.clip((ratio - 2.0) / 18.0, 0.0, 1.0))


def simulate_rf(
    attack_type: str,
    countermeasure: str,
    jsr_trim_db: float,
    snr_db: float,
    duty_cycle: float,
    live_index: int,
    carrier_mhz: float,
    signal_bandwidth_khz: float,
    tx_power_dbm: float,
    jammer_power_dbm: float,
    tx_gain_dbi: float,
    rx_gain_dbi: float,
    jammer_gain_dbi: float,
    link_distance_m: float,
    attacker_distance_m: float,
    path_loss_exponent: float,
    noise_figure_db: float,
    jammer_center_khz: float,
    sweep_span_khz: float,
) -> RFResult:
    rng = np.random.default_rng(SAFE_RANDOM_SEED + 17 * live_index)
    tx = generate_pn_bpsk(N, live_index)
    signal_power = safe_power(tx)

    budget = compute_link_budget(
        carrier_mhz=carrier_mhz,
        signal_bandwidth_khz=signal_bandwidth_khz,
        tx_power_dbm=tx_power_dbm,
        jammer_power_dbm=jammer_power_dbm,
        tx_gain_dbi=tx_gain_dbi,
        rx_gain_dbi=rx_gain_dbi,
        jammer_gain_dbi=jammer_gain_dbi,
        link_distance_m=link_distance_m,
        attacker_distance_m=attacker_distance_m,
        path_loss_exponent=path_loss_exponent,
        noise_figure_db=noise_figure_db,
        jsr_trim_db=jsr_trim_db,
    )

    # Use the weaker of the user-selected background SNR and the link-budget SNR.
    # This keeps the dashboard qualitative while allowing distance, frequency,
    # power, antenna gain, bandwidth, and noise figure to affect the scopes.
    snr_for_noise_db = float(np.clip(min(float(snr_db), budget.link_budget_snr_db), -20.0, 60.0))
    noise_power = signal_power / db_to_linear(snr_for_noise_db)
    noise = rng.normal(0.0, math.sqrt(noise_power), N)
    jammer, dropout_factor = jammer_waveform(
        attack_type, tx, FS, budget.effective_jsr_db, duty_cycle, live_index, rng,
        jammer_center_khz=jammer_center_khz, sweep_span_khz=sweep_span_khz,
    )

    raw_rx = tx + noise + jammer
    factor = residual_jammer_factor(attack_type, countermeasure)
    protected_rx = tx + noise + factor * jammer

    if countermeasure in ("notch", "full_defense"):
        protected_rx = spectral_notch_filter(protected_rx, FS)

    residual_interference_power = safe_power(protected_rx - tx)
    effective_snr_db = 10.0 * math.log10(signal_power / residual_interference_power)
    q_corr = correlation_quality(protected_rx, tx)

    # Toy packet-delivery model. It is intentionally qualitative.
    pdr_base = sigmoid((effective_snr_db - 3.0) / 3.5)
    pdr = pdr_base * (1.0 - dropout_factor)
    if countermeasure in ("adaptive_safe", "full_defense"):
        pdr = min(1.0, pdr + 0.10)
    if attack_type == "gps_spoofing" and countermeasure in ("fusion_gate", "full_defense"):
        pdr = min(1.0, pdr + 0.05)
    pdr = float(np.clip(pdr, 0.0, 1.0))

    if pdr > 0.75 and q_corr > 0.55:
        link_state = "Nominal"
    elif pdr > 0.40:
        link_state = "Degraded"
    else:
        link_state = "Critical"

    t_ms = np.arange(N, dtype=float) / FS * 1e3
    raw_jsr_db = 10.0 * math.log10(safe_power(jammer) / signal_power) if safe_power(jammer) > 1e-10 else -80.0

    return RFResult(
        tx=tx,
        jammer=jammer,
        raw_rx=raw_rx,
        protected_rx=protected_rx,
        t_ms=t_ms,
        effective_snr_db=float(effective_snr_db),
        raw_jsr_db=float(raw_jsr_db),
        pdr=pdr,
        correlation_quality=q_corr,
        link_state=link_state,
        dropout_factor=dropout_factor,
        link_budget=budget,
    )


# -----------------------------------------------------------------------------
# GPS-denied navigation, spoofing, and defensive fusion models
# -----------------------------------------------------------------------------
def true_trajectory(n_steps: int) -> np.ndarray:
    u = np.linspace(0.0, 1.0, n_steps)
    x = -35.0 + 70.0 * u
    y = 8.0 * np.sin(2.0 * math.pi * u) + 3.5 * np.sin(5.0 * math.pi * u)
    z = 10.0 + 1.0 * np.sin(math.pi * u)
    return np.column_stack([x, y, z])


def gps_spoof_bias(n_steps: int, attack_type: str, spoof_bias_m: float, live_index: int) -> np.ndarray:
    u = np.linspace(0.0, 1.0, n_steps)
    if attack_type == "gps_spoofing":
        growth = smoothstep(min(1.0, (live_index % n_steps) / max(1, n_steps - 1)))
        bx = spoof_bias_m * growth * (0.30 + 0.70 * u)
        by = -0.65 * spoof_bias_m * growth * (u ** 1.2)
        bz = 0.15 * spoof_bias_m * growth * np.sin(math.pi * u)
    elif attack_type == "failsafe":
        bx = 0.18 * spoof_bias_m * np.sin(2.0 * math.pi * u)
        by = 0.18 * spoof_bias_m * np.cos(2.0 * math.pi * u)
        bz = np.zeros_like(u)
    else:
        bx = np.zeros_like(u)
        by = np.zeros_like(u)
        bz = np.zeros_like(u)
    return np.column_stack([bx, by, bz])


def build_sensor_paths(
    attack_type: str,
    countermeasure: str,
    rf: RFResult,
    spoof_bias_m: float,
    live_index: int,
) -> NavResult:
    rng = np.random.default_rng(SAFE_RANDOM_SEED + 101)
    true_path = true_trajectory(N_STEPS)
    current_step = int(live_index % N_STEPS)

    gps_noise = rng.normal(0.0, 0.35, true_path.shape)
    gps_noise[:, 2] *= 0.4
    gps_path = true_path + gps_noise + gps_spoof_bias(N_STEPS, attack_type, spoof_bias_m, live_index)

    # VIO is stable in the short term but drifts slowly.
    vio_noise = rng.normal(0.0, 0.18, true_path.shape)
    drift = np.column_stack([
        np.linspace(0.0, 1.4, N_STEPS),
        np.linspace(0.0, -0.8, N_STEPS),
        np.linspace(0.0, 0.2, N_STEPS),
    ])
    vio_path = true_path + vio_noise + drift

    # TDoA degrades when the RF link is poor.
    tdoa_sigma = 0.20 + 2.8 * (1.0 - rf.pdr) + 1.2 * (1.0 - rf.correlation_quality)
    tdoa_path = true_path + rng.normal(0.0, tdoa_sigma, true_path.shape)
    tdoa_path[:, 2] = true_path[:, 2] + rng.normal(0.0, 0.35 + 0.6 * (1.0 - rf.pdr), N_STEPS)

    gps_innovation = float(np.linalg.norm(gps_path[current_step] - vio_path[current_step]))
    spoof_detected = gps_innovation > max(4.0, 0.35 * spoof_bias_m)

    if countermeasure in ("fusion_gate", "full_defense") and spoof_detected:
        gps_w = 0.04
        vio_w = 0.54
        tdoa_w = 0.42 if rf.pdr > 0.35 else 0.22
    elif countermeasure in ("adaptive_safe", "full_defense") and rf.link_state == "Critical":
        gps_w = 0.18
        vio_w = 0.68
        tdoa_w = 0.14
    else:
        gps_w = 0.48
        vio_w = 0.30
        tdoa_w = 0.22

    weight_sum = gps_w + vio_w + tdoa_w
    gps_w, vio_w, tdoa_w = gps_w / weight_sum, vio_w / weight_sum, tdoa_w / weight_sum
    fused_path = gps_w * gps_path + vio_w * vio_path + tdoa_w * tdoa_path

    loc_error = float(np.linalg.norm(fused_path[current_step] - true_path[current_step]))
    safe_mode = False
    if rf.link_state == "Critical" or (spoof_detected and countermeasure in ("adaptive_safe", "full_defense", "fusion_gate")):
        safe_mode = True

    if attack_type == "none":
        mission_state = "Mapping / nominal navigation"
    elif safe_mode and countermeasure in ("adaptive_safe", "full_defense"):
        mission_state = "Safe mode: slow flight, hold/hover, DTN store-carry-forward"
    elif safe_mode and countermeasure == "fusion_gate":
        mission_state = "GPS rejected: VIO/TDoA-aided navigation"
    elif rf.link_state == "Critical":
        mission_state = "Failsafe risk: command link and localization degraded"
    elif spoof_detected:
        mission_state = "Spoofing anomaly detected but not fully mitigated"
    else:
        mission_state = "Mission continues with degraded confidence"

    return NavResult(
        true_path=true_path,
        gps_path=gps_path,
        vio_path=vio_path,
        tdoa_path=tdoa_path,
        fused_path=fused_path,
        current_step=current_step,
        gps_innovation_m=gps_innovation,
        localization_error_m=loc_error,
        mission_state=mission_state,
        spoof_detected=spoof_detected,
        safe_mode=safe_mode,
    )


def run_simulation(
    attack_type: str,
    countermeasure: str,
    jsr_db: float,
    snr_db: float,
    duty_cycle: float,
    spoof_bias_m: float,
    live_index: int,
    carrier_mhz: float,
    signal_bandwidth_khz: float,
    tx_power_dbm: float,
    jammer_power_dbm: float,
    tx_gain_dbi: float,
    rx_gain_dbi: float,
    jammer_gain_dbi: float,
    link_distance_m: float,
    attacker_distance_m: float,
    path_loss_exponent: float,
    noise_figure_db: float,
    jammer_center_khz: float,
    sweep_span_khz: float,
) -> SimulationResult:
    rf = simulate_rf(
        attack_type=attack_type,
        countermeasure=countermeasure,
        jsr_trim_db=jsr_db,
        snr_db=snr_db,
        duty_cycle=duty_cycle,
        live_index=live_index,
        carrier_mhz=carrier_mhz,
        signal_bandwidth_khz=signal_bandwidth_khz,
        tx_power_dbm=tx_power_dbm,
        jammer_power_dbm=jammer_power_dbm,
        tx_gain_dbi=tx_gain_dbi,
        rx_gain_dbi=rx_gain_dbi,
        jammer_gain_dbi=jammer_gain_dbi,
        link_distance_m=link_distance_m,
        attacker_distance_m=attacker_distance_m,
        path_loss_exponent=path_loss_exponent,
        noise_figure_db=noise_figure_db,
        jammer_center_khz=jammer_center_khz,
        sweep_span_khz=sweep_span_khz,
    )
    nav = build_sensor_paths(attack_type, countermeasure, rf, spoof_bias_m, live_index)

    b = rf.link_budget
    status = {
        "attack": ATTACK_TYPES.get(attack_type, attack_type),
        "symptom": ATTACK_SYMPTOMS.get(attack_type, "Unknown"),
        "countermeasure": COUNTERMEASURES.get(countermeasure, countermeasure),
        "countermeasure_note": COUNTERMEASURE_NOTES.get(countermeasure, ""),
        "mission": nav.mission_state,
        "rf_controls": (
            f"carrier={b.carrier_mhz:.0f} MHz | BW={b.signal_bandwidth_khz:.0f} kHz | "
            f"link={b.link_distance_m:.1f} m | attacker={b.attacker_distance_m:.1f} m"
        ),
        "link_budget": (
            f"Prx={b.legitimate_rx_dbm:.1f} dBm | Jrx={b.jammer_rx_dbm:.1f} dBm | "
            f"SNR_budget={b.link_budget_snr_db:.1f} dB | J/S={b.effective_jsr_db:.1f} dB"
        ),
        "safety_note": "Abstract educational model only: no RF transmission, no hardware control, and no operational attack guidance.",
    }
    return SimulationResult(rf=rf, nav=nav, attack_type=attack_type, countermeasure=countermeasure, live_index=live_index, status=status)


# -----------------------------------------------------------------------------
# Plot helpers
# -----------------------------------------------------------------------------
def base_layout(fig: go.Figure, title: str, height: int = 430) -> go.Figure:
    fig.update_layout(
        title=title,
        template="plotly_white",
        height=height,
        margin=dict(l=42, r=24, t=58, b=42),
        uirevision="education-sim",
        transition=dict(duration=0),
        legend=dict(orientation="h", yanchor="bottom", y=-0.28, xanchor="left", x=0.0),
    )
    return fig


def spectrum_db(x: np.ndarray, fs: float) -> Tuple[np.ndarray, np.ndarray]:
    n = len(x)
    w = np.hanning(n)
    X = np.fft.fftshift(np.fft.fft(x * w))
    f = np.fft.fftshift(np.fft.fftfreq(n, d=1.0 / fs)) / 1000.0
    p = 20.0 * np.log10(np.abs(X) + 1e-12)
    p -= float(np.max(p))
    return f, p


def spectrogram_db(x: np.ndarray, fs: float, nfft: int = 256, hop: int = 96) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    frames: List[np.ndarray] = []
    for start in range(0, len(x) - nfft, hop):
        seg = x[start:start + nfft] * np.hanning(nfft)
        X = np.fft.fftshift(np.fft.fft(seg))
        frames.append(20.0 * np.log10(np.abs(X) + 1e-12))
    S = np.asarray(frames)
    if S.size:
        S -= np.max(S)
    f = np.fft.fftshift(np.fft.fftfreq(nfft, d=1.0 / fs)) / 1000.0
    t = np.arange(S.shape[0], dtype=float) * hop / fs * 1000.0
    return f, t, S


def fig_waveforms(sim: SimulationResult) -> go.Figure:
    rf = sim.rf
    n_show = 1200
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=rf.t_ms[:n_show], y=rf.tx[:n_show], mode="lines", name="Legitimate drone link signal"))
    fig.add_trace(go.Scatter(x=rf.t_ms[:n_show], y=rf.jammer[:n_show], mode="lines", name="Simulated jammer/deceptive component"))
    fig.add_trace(go.Scatter(x=rf.t_ms[:n_show], y=rf.raw_rx[:n_show], mode="lines", name="Raw receiver"))
    fig.add_trace(go.Scatter(x=rf.t_ms[:n_show], y=rf.protected_rx[:n_show], mode="lines", name="After countermeasure"))
    fig.update_xaxes(title="Time (ms)")
    fig.update_yaxes(title="Normalized amplitude")
    return base_layout(fig, "Scope 1 — Baseband Waveform and Jamming Effect")


def fig_spectrum(sim: SimulationResult) -> go.Figure:
    rf = sim.rf
    fig = go.Figure()
    for label, signal in [
        ("TX", rf.tx),
        ("Jammer", rf.jammer),
        ("Raw RX", rf.raw_rx),
        ("Protected RX", rf.protected_rx),
    ]:
        f, p = spectrum_db(signal, FS)
        fig.add_trace(go.Scatter(x=f, y=p, mode="lines", name=label))
    fig.update_xaxes(title="Normalized baseband frequency offset (kHz)")
    fig.update_yaxes(title="Relative magnitude (dB)")
    return base_layout(fig, "Scope 2 — Spectrum Before and After Countermeasure")


def fig_waterfall(sim: SimulationResult) -> go.Figure:
    f, t, S = spectrogram_db(sim.rf.raw_rx, FS)
    fig = go.Figure(data=go.Heatmap(x=f, y=t, z=S, colorscale="Viridis", colorbar=dict(title="dB")))
    fig.update_xaxes(title="Normalized baseband frequency offset (kHz)")
    fig.update_yaxes(title="Time (ms)")
    return base_layout(fig, "Scope 3 — Waterfall / Time-Frequency View of Attack")


def fig_navigation(sim: SimulationResult) -> go.Figure:
    nav = sim.nav
    k = nav.current_step
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=nav.true_path[:, 0], y=nav.true_path[:, 1], mode="lines", name="True path"
    ))
    fig.add_trace(go.Scatter(
        x=nav.gps_path[:, 0], y=nav.gps_path[:, 1], mode="lines", name="GPS-like estimate"
    ))
    fig.add_trace(go.Scatter(
        x=nav.vio_path[:, 0], y=nav.vio_path[:, 1], mode="lines", name="VIO estimate"
    ))
    fig.add_trace(go.Scatter(
        x=nav.tdoa_path[:, 0], y=nav.tdoa_path[:, 1], mode="lines", name="TDoA estimate"
    ))
    fig.add_trace(go.Scatter(
        x=nav.fused_path[:, 0], y=nav.fused_path[:, 1], mode="lines", name="Fused navigation"
    ))

    # Current-position markers.
    labels = [
        ("True drone", nav.true_path[k]),
        ("GPS-like", nav.gps_path[k]),
        ("VIO", nav.vio_path[k]),
        ("TDoA", nav.tdoa_path[k]),
        ("Fused", nav.fused_path[k]),
    ]
    for label, point in labels:
        fig.add_trace(go.Scatter(
            x=[point[0]], y=[point[1]], mode="markers+text", text=[label], textposition="top center", name=f"{label} live"
        ))

    # Educational jammer/spoofer influence zone. The radius is driven by the
    # attack-distance control, but it remains an abstract visualization.
    b = sim.rf.link_budget
    theta = np.linspace(0, 2.0 * math.pi, 100)
    attacker_x, attacker_y = -5.0, 0.0
    zone_radius = float(np.clip(b.attacker_distance_m, 4.0, 40.0))
    zone_x = attacker_x + zone_radius * np.cos(theta)
    zone_y = attacker_y + zone_radius * np.sin(theta)
    fig.add_trace(go.Scatter(x=zone_x, y=zone_y, mode="lines", name=f"Attack influence zone ≈ {zone_radius:.0f} m"))
    fig.add_trace(go.Scatter(
        x=[attacker_x], y=[attacker_y], mode="markers+text", text=["Jammer / spoofer"],
        textposition="bottom center", name="Simulated attacker location"
    ))

    fig.update_xaxes(title="x position (m)", range=[-45, 45], scaleanchor="y", scaleratio=1)
    fig.update_yaxes(title="y position (m)", range=[-28, 28])
    subtitle = f"error={nav.localization_error_m:.2f} m | GPS innovation={nav.gps_innovation_m:.2f} m"
    return base_layout(fig, f"Scope 4 — Navigation, GPS Spoofing, and Sensor Fusion | {subtitle}")


def fig_metrics(sim: SimulationResult) -> go.Figure:
    rf = sim.rf
    nav = sim.nav
    b = rf.link_budget
    names = [
        "Effective SNR",
        "Actual J/S",
        "Packet delivery",
        "Correlation quality",
        "Budget SNR",
        "GPS innovation",
        "Localization error",
    ]
    values = [
        rf.effective_snr_db,
        rf.raw_jsr_db,
        100.0 * rf.pdr,
        100.0 * rf.correlation_quality,
        b.link_budget_snr_db,
        nav.gps_innovation_m,
        nav.localization_error_m,
    ]
    units = ["dB", "dB", "%", "%", "dB", "m", "m"]

    fig = make_subplots(rows=1, cols=1)
    fig.add_trace(go.Bar(x=names, y=values, text=[f"{v:.2f} {u}" for v, u in zip(values, units)], textposition="auto"))
    fig.update_xaxes(title="Metric")
    fig.update_yaxes(title="Value")
    return base_layout(fig, "Scope 5 — Mission and Countermeasure Metrics")


def make_status_cards(sim: SimulationResult) -> html.Div:
    rf = sim.rf
    nav = sim.nav

    cards = [
        ("Attack model", sim.status["attack"]),
        ("Observed symptom", sim.status["symptom"]),
        ("Countermeasure", sim.status["countermeasure"]),
        ("Countermeasure note", sim.status["countermeasure_note"]),
        ("RF controls", sim.status["rf_controls"]),
        ("Link budget", sim.status["link_budget"]),
        ("Link state", f"{rf.link_state} | PDR={100.0 * rf.pdr:.1f}% | SNR={rf.effective_snr_db:.2f} dB"),
        ("Navigation state", sim.status["mission"]),
        ("Spoofing detector", "Triggered" if nav.spoof_detected else "Not triggered"),
        ("Safety note", sim.status["safety_note"]),
    ]

    return html.Div(
        style={"display": "grid", "gridTemplateColumns": "repeat(4, minmax(180px, 1fr))", "gap": "10px"},
        children=[
            html.Div(
                style={
                    "background": "#ffffff",
                    "border": "1px solid #d8e2f0",
                    "borderRadius": "10px",
                    "padding": "10px",
                    "boxShadow": "0 1px 2px rgba(0,0,0,0.05)",
                },
                children=[
                    html.Div(title, style={"fontWeight": "700", "fontSize": "12px", "color": "#2c4774", "marginBottom": "4px"}),
                    html.Div(value, style={"fontSize": "12px", "lineHeight": "1.35"}),
                ],
            )
            for title, value in cards
        ],
    )


def make_position_table(sim: SimulationResult) -> html.Table:
    nav = sim.nav
    k = nav.current_step
    rows = [
        ("True", nav.true_path[k]),
        ("GPS-like", nav.gps_path[k]),
        ("VIO", nav.vio_path[k]),
        ("TDoA", nav.tdoa_path[k]),
        ("Fused", nav.fused_path[k]),
    ]
    header_style = {"background": "#eaf3ff", "padding": "7px", "textAlign": "left", "borderBottom": "1px solid #c8d6ea"}
    cell_style = {"padding": "7px", "borderBottom": "1px solid #edf1f7"}
    return html.Table(
        style={"width": "100%", "borderCollapse": "collapse", "background": "white", "fontSize": "12px"},
        children=[
            html.Thead(html.Tr([
                html.Th("Estimator", style=header_style),
                html.Th("x (m)", style=header_style),
                html.Th("y (m)", style=header_style),
                html.Th("z (m)", style=header_style),
                html.Th("Error to true (m)", style=header_style),
            ])),
            html.Tbody([
                html.Tr([
                    html.Td(name, style=cell_style),
                    html.Td(f"{point[0]:.2f}", style=cell_style),
                    html.Td(f"{point[1]:.2f}", style=cell_style),
                    html.Td(f"{point[2]:.2f}", style=cell_style),
                    html.Td(f"{np.linalg.norm(point - nav.true_path[k]):.2f}", style=cell_style),
                ])
                for name, point in rows
            ]),
        ],
    )



# -----------------------------------------------------------------------------
# Dash application with tabbed controls, adjusted scopes, and Start/Stop/Reset
# -----------------------------------------------------------------------------
app = Dash(__name__)
app.title = "Drone Attack and Countermeasure Educational Simulator"

PAGE_STYLE = {
    "fontFamily": "Arial, Helvetica, sans-serif",
    "background": "#f5f7fb",
    "minHeight": "100vh",
    "padding": "18px",
    "color": "#1f2d3d",
}

PANEL_STYLE = {
    "background": "#ffffff",
    "border": "1px solid #d8e2f0",
    "borderRadius": "12px",
    "padding": "14px",
    "boxShadow": "0 1px 3px rgba(0,0,0,0.05)",
}

LABEL_STYLE = {"fontWeight": "700", "fontSize": "12px", "marginBottom": "4px", "color": "#2c4774"}
TAB_STYLE = {"padding": "9px", "fontSize": "13px"}
SELECTED_TAB_STYLE = {"padding": "9px", "fontSize": "13px", "fontWeight": "700", "color": "#243f7a"}

BUTTON_STYLE = {
    "border": "0",
    "borderRadius": "8px",
    "padding": "9px 14px",
    "fontWeight": "700",
    "cursor": "pointer",
    "fontSize": "13px",
}

HELP_BUTTON_STYLE = {
    "border": "1px solid #9fb7d9",
    "borderRadius": "8px",
    "padding": "7px 10px",
    "fontWeight": "700",
    "cursor": "pointer",
    "fontSize": "12px",
    "background": "#f3f8ff",
    "color": "#243f7a",
}

HELP_TOPICS = {
    "welcome": {
        "title": "Help Mode — Drone Attack and Countermeasure Simulator",
        "bullets": [
            "Use Start to advance the live simulation frame, Stop to freeze the scenario, and Reset to return to frame zero.",
            "The simulator is divided into control tabs and scope tabs. Control tabs modify the scenario; scope tabs show the effect on signals, link budget, and navigation.",
            "All attack models are normalized baseband and educational only. The dashboard does not transmit RF energy and does not control real drones.",
            "Click any help button in the Control Panel to open an emergent explanation window for that group of parameters.",
        ],
    },
    "mission": {
        "title": "Mission Controls",
        "bullets": [
            "Attack / anomaly type selects the simulated RF or navigation degradation model, such as noise jamming, sweep jamming, reactive jamming, failsafe-triggering behavior, or GPS spoofing.",
            "Countermeasure selects the defensive response, such as notch filtering, hopping diversity, sensor-fusion gating, adaptive safe mode, or the combined defense stack.",
            "Update interval controls the live refresh speed of the scopes and the mission frame counter.",
            "Use this tab to compare how the same mission behaves with different attack and defense combinations.",
        ],
    },
    "rf_link": {
        "title": "RF Link Controls",
        "bullets": [
            "Carrier frequency changes the educational link-budget path-loss calculation.",
            "Signal bandwidth affects the modeled noise floor and the visible baseband spectrum.",
            "Legitimate TX power, TX gain, and RX gain increase the received useful signal level.",
            "Attack-source power and attack antenna gain increase the received interference level at the drone receiver.",
            "The link-budget scope converts these settings into received power, SNR, and jammer-to-signal ratio.",
        ],
    },
    "channel": {
        "title": "Geometry and Channel Controls",
        "bullets": [
            "Drone link distance increases the path loss between the legitimate transmitter and receiver.",
            "Attack-source distance changes how strongly the simulated jammer or spoofer couples into the receiver.",
            "Path-loss exponent models the propagation environment. A value near 2 represents open LOS-like behavior; higher values represent obstructed or cluttered environments.",
            "Receiver noise figure raises or lowers the modeled receiver noise floor.",
            "Background SNR limit applies an additional practical ceiling to the effective received link quality.",
        ],
    },
    "attack_waveform": {
        "title": "Attack Waveform Controls",
        "bullets": [
            "J/S manual trim adds an educational offset to the jammer-to-signal ratio after the link-budget calculation.",
            "Jammer center offset moves the tone or narrowband interference in the baseband spectrum display.",
            "Sweep / barrage span controls how wide sweep and multi-tone interference appear in the spectrum and waterfall scopes.",
            "Duty cycle controls pulsed, intermittent, and reactive attack visibility in time-domain scopes.",
            "These controls are not hardware instructions; they only shape normalized numerical waveforms for visualization.",
        ],
    },
    "navigation": {
        "title": "Navigation and GPS-Spoofing Controls",
        "bullets": [
            "GPS spoofing maximum bias controls how far the GPS-like estimate can drift away from the true path.",
            "The navigation scope compares true, GPS-like, VIO, TDoA, and fused estimates.",
            "Fusion gating and the full defense stack can reject inconsistent GPS-like measurements and rely more strongly on VIO/TDoA.",
            "Safe mode is triggered when localization error, spoofing innovation, or link degradation exceeds the educational thresholds.",
        ],
    },
    "scopes": {
        "title": "Scope Tabs",
        "bullets": [
            "Overview shows the navigation path, summary metrics, and mission health indicators.",
            "RF Scopes show the baseband waveform, spectrum, and waterfall before and after countermeasures.",
            "Link Budget shows received signal power, received attack power, noise floor, SNR, J/S, packet delivery, and the live RF budget table.",
            "Use the scopes together: the waveform/spectrum explain the RF symptom, while the navigation and metrics show the mission-level consequence.",
        ],
    },
    "start_stop_reset": {
        "title": "Start, Stop, and Reset",
        "bullets": [
            "Start enables the interval timer and advances the live frame counter.",
            "Stop freezes the scenario so that parameter effects can be inspected without motion.",
            "Reset stops the simulation and returns the mission to frame zero.",
            "Parameter changes are applied immediately, even while the simulation is stopped.",
        ],
    },
    "safety": {
        "title": "Safe Educational Use",
        "bullets": [
            "This simulator is designed for book figures, classroom explanation, and defensive analysis.",
            "It uses normalized numerical waveforms only and does not provide operational RF attack procedures.",
            "The purpose is to understand symptoms, detection indicators, and countermeasure logic for resilient UAV systems.",
        ],
    },
}


def help_button(topic: str, label: str | None = None) -> html.Button:
    """Small help button that opens an emergent explanatory window."""
    return html.Button(
        label or "?",
        id={"type": "help-topic", "topic": topic},
        n_clicks=0,
        title=f"Open help: {HELP_TOPICS.get(topic, {}).get('title', topic)}",
        style=HELP_BUTTON_STYLE,
    )


def make_help_topic_buttons() -> html.Div:
    return html.Div(
        style={"display": "flex", "flexWrap": "wrap", "gap": "7px", "margin": "8px 0 12px 0"},
        children=[
            help_button("mission", "Mission"),
            help_button("rf_link", "RF Link"),
            help_button("channel", "Geometry"),
            help_button("attack_waveform", "Attack Waveform"),
            help_button("navigation", "Navigation"),
            help_button("scopes", "Scopes"),
            help_button("start_stop_reset", "Start/Stop/Reset"),
            help_button("safety", "Safety"),
        ],
    )


def make_help_body(topic: str):
    info = HELP_TOPICS.get(topic, HELP_TOPICS["welcome"])
    return html.Div(children=[
        html.P(
            "This emergent help window explains how to use the selected simulator controls and how to interpret the resulting scopes.",
            style={"marginTop": 0, "fontSize": "13px", "color": "#4a5d7a", "lineHeight": "1.5"},
        ),
        html.Ul(
            [html.Li(item, style={"marginBottom": "8px", "lineHeight": "1.45"}) for item in info["bullets"]],
            style={"paddingLeft": "20px", "fontSize": "13px"},
        ),
    ])


def help_modal_style(visible: bool) -> dict:
    return {
        "display": "flex" if visible else "none",
        "position": "fixed",
        "zIndex": "9999",
        "left": "0",
        "top": "0",
        "width": "100%",
        "height": "100%",
        "background": "rgba(14, 27, 46, 0.55)",
        "alignItems": "center",
        "justifyContent": "center",
        "padding": "20px",
    }


def make_help_modal() -> html.Div:
    return html.Div(
        id="help-modal",
        style=help_modal_style(False),
        children=[
            html.Div(
                style={
                    "background": "#ffffff",
                    "borderRadius": "14px",
                    "border": "1px solid #c8d6ea",
                    "boxShadow": "0 18px 50px rgba(0,0,0,0.25)",
                    "width": "min(720px, 95vw)",
                    "maxHeight": "82vh",
                    "overflowY": "auto",
                    "padding": "18px",
                },
                children=[
                    html.Div(
                        style={"display": "flex", "justifyContent": "space-between", "alignItems": "flex-start", "gap": "12px"},
                        children=[
                            html.H2(id="help-modal-title", style={"margin": "0", "color": "#243f7a", "fontSize": "20px"}),
                            html.Button("×", id="btn-help-close", n_clicks=0, style={**BUTTON_STYLE, "background": "#ffe3e3", "color": "#9f1d1d", "fontSize": "18px", "padding": "4px 10px"}),
                        ],
                    ),
                    html.Hr(style={"border": "0", "borderTop": "1px solid #edf1f7"}),
                    html.Div(id="help-modal-body"),
                ],
            )
        ],
    )


def control_block(label: str, child) -> html.Div:
    return html.Div([html.Div(label, style=LABEL_STYLE), child], style={"marginBottom": "14px"})


def two_col(children):
    return html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "12px"}, children=children)


def figure_panel(graph_id: str, title: str | None = None, span: bool = False, help_topic: str | None = None):
    children = []
    if title:
        title_children = [html.Div(title, style={"fontWeight": "700", "color": "#243f7a"})]
        if help_topic:
            title_children.append(help_button(help_topic))
        children.append(html.Div(
            title_children,
            style={"display": "flex", "justifyContent": "space-between", "alignItems": "center", "gap": "8px", "marginBottom": "8px"},
        ))
    children.append(dcc.Graph(id=graph_id, config={"displayModeBar": False, "responsive": True}))
    return html.Div(style={**PANEL_STYLE, **({"gridColumn": "1 / span 2"} if span else {})}, children=children)


def fig_link_budget(sim: SimulationResult) -> go.Figure:
    """RF link-budget scope driven by the user controls."""
    b = sim.rf.link_budget
    metrics = [
        ("Legitimate path loss", b.legitimate_path_loss_db, "dB"),
        ("Attack path loss", b.jammer_path_loss_db, "dB"),
        ("Legitimate received power", b.legitimate_rx_dbm, "dBm"),
        ("Attack received power", b.jammer_rx_dbm, "dBm"),
        ("Noise floor", b.noise_floor_dbm, "dBm"),
        ("Budget SNR", b.link_budget_snr_db, "dB"),
        ("Effective J/S", b.effective_jsr_db, "dB"),
        ("PDR", 100.0 * sim.rf.pdr, "%"),
    ]
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=[m[0] for m in metrics],
        y=[m[1] for m in metrics],
        text=[f"{m[1]:.2f} {m[2]}" for m in metrics],
        textposition="auto",
        name="Link budget"
    ))
    fig.update_xaxes(title="Budget metric")
    fig.update_yaxes(title="Value")
    return base_layout(fig, "Scope 6 — RF Link Budget and Attack Coupling", height=460)


def fig_scope_summary(sim: SimulationResult) -> go.Figure:
    """Compact multi-metric scope for dashboard overview."""
    rf = sim.rf
    nav = sim.nav
    b = rf.link_budget
    labels = [
        "PDR (%)", "Correlation (%)", "Effective SNR (dB)", "J/S (dB)",
        "GPS innovation (m)", "Localization error (m)", "Budget SNR (dB)", "Dropout (%)"
    ]
    values = [
        100.0 * rf.pdr,
        100.0 * rf.correlation_quality,
        rf.effective_snr_db,
        b.effective_jsr_db,
        nav.gps_innovation_m,
        nav.localization_error_m,
        b.link_budget_snr_db,
        100.0 * rf.dropout_factor,
    ]
    fig = go.Figure(go.Bar(x=labels, y=values, text=[f"{v:.2f}" for v in values], textposition="auto"))
    fig.update_xaxes(title="Live metric")
    fig.update_yaxes(title="Value")
    return base_layout(fig, "Scope 7 — Live Simulation Summary", height=420)


def make_link_budget_table(sim: SimulationResult) -> html.Table:
    b = sim.rf.link_budget
    rows = [
        ("Carrier frequency", f"{b.carrier_mhz:.0f} MHz"),
        ("Signal bandwidth", f"{b.signal_bandwidth_khz:.0f} kHz"),
        ("Legitimate TX power", f"{b.tx_power_dbm:.1f} dBm"),
        ("Attack-source power", f"{b.jammer_power_dbm:.1f} dBm"),
        ("TX / RX / attack antenna gain", f"{b.tx_gain_dbi:.1f} / {b.rx_gain_dbi:.1f} / {b.jammer_gain_dbi:.1f} dBi"),
        ("Drone link distance", f"{b.link_distance_m:.1f} m"),
        ("Attack-source distance", f"{b.attacker_distance_m:.1f} m"),
        ("Path-loss exponent", f"{b.path_loss_exponent:.2f}"),
        ("Receiver noise figure", f"{b.noise_figure_db:.1f} dB"),
        ("Legitimate received power", f"{b.legitimate_rx_dbm:.2f} dBm"),
        ("Attack received power", f"{b.jammer_rx_dbm:.2f} dBm"),
        ("Noise floor", f"{b.noise_floor_dbm:.2f} dBm"),
        ("Budget SNR", f"{b.link_budget_snr_db:.2f} dB"),
        ("Effective J/S", f"{b.effective_jsr_db:.2f} dB"),
    ]
    header_style = {"background": "#eaf3ff", "padding": "7px", "textAlign": "left", "borderBottom": "1px solid #c8d6ea"}
    cell_style = {"padding": "7px", "borderBottom": "1px solid #edf1f7"}
    return html.Table(
        style={"width": "100%", "borderCollapse": "collapse", "background": "white", "fontSize": "12px"},
        children=[
            html.Thead(html.Tr([html.Th("Parameter", style=header_style), html.Th("Live value", style=header_style)])),
            html.Tbody([html.Tr([html.Td(k, style=cell_style), html.Td(v, style=cell_style)]) for k, v in rows]),
        ],
    )


def make_run_status(state: dict, update_ms: int) -> html.Div:
    running = bool(state.get("running", False)) if isinstance(state, dict) else False
    live_index = int(state.get("live_index", 0)) if isinstance(state, dict) else 0
    badge = "RUNNING" if running else "STOPPED"
    color = "#176b2c" if running else "#9f1d1d"
    return html.Div([
        html.B(f"Simulation: {badge}", style={"color": color}),
        html.Span(f"  | frame={live_index} | update={int(update_ms)} ms", style={"marginLeft": "8px", "fontSize": "12px", "color": "#4a5d7a"}),
    ])


# ----- Tabbed controls ---------------------------------------------------------
controls_tabs = dcc.Tabs(
    id="control-tabs",
    value="tab-basic",
    children=[
        dcc.Tab(label="Mission", value="tab-basic", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
            html.Div(style={"paddingTop": "12px"}, children=[
                control_block("Attack / anomaly type", dcc.Dropdown(
                    id="attack-type",
                    options=[{"label": label, "value": key} for key, label in ATTACK_TYPES.items()],
                    value="noise",
                    clearable=False,
                )),
                control_block("Countermeasure", dcc.Dropdown(
                    id="countermeasure",
                    options=[{"label": label, "value": key} for key, label in COUNTERMEASURES.items()],
                    value="full_defense",
                    clearable=False,
                )),
                control_block("Update interval (ms)", dcc.Slider(
                    id="update-ms", min=250, max=2000, step=250, value=750,
                    marks={250: "250", 750: "750", 1000: "1000", 2000: "2000"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                html.Div(
                    "Start/Stop/Reset buttons control the live frame counter. Controls can be changed while the simulator is stopped or running.",
                    style={"fontSize": "12px", "lineHeight": "1.45", "color": "#4a5d7a"},
                ),
            ])
        ]),
        dcc.Tab(label="RF Link", value="tab-rf", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
            html.Div(style={"paddingTop": "12px"}, children=[
                control_block("Carrier / band center frequency (MHz)", dcc.Slider(
                    id="carrier-mhz", min=400, max=6000, step=100, value=2400,
                    marks={400: "400", 2400: "2400", 5800: "5800"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Signal bandwidth (kHz)", dcc.Slider(
                    id="signal-bandwidth-khz", min=20, max=500, step=10, value=200,
                    marks={20: "20", 200: "200", 500: "500"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                two_col([
                    control_block("Legitimate TX power (dBm)", dcc.Slider(
                        id="tx-power-dbm", min=-20, max=30, step=1, value=10,
                        marks={-20: "-20", 0: "0", 10: "10", 30: "30"},
                        tooltip={"placement": "bottom", "always_visible": False},
                    )),
                    control_block("Attack-source power (dBm)", dcc.Slider(
                        id="jammer-power-dbm", min=-20, max=40, step=1, value=15,
                        marks={-20: "-20", 0: "0", 20: "20", 40: "40"},
                        tooltip={"placement": "bottom", "always_visible": False},
                    )),
                ]),
                two_col([
                    control_block("TX antenna gain (dBi)", dcc.Slider(
                        id="tx-gain-dbi", min=-5, max=15, step=1, value=2,
                        marks={-5: "-5", 0: "0", 10: "10", 15: "15"},
                        tooltip={"placement": "bottom", "always_visible": False},
                    )),
                    control_block("RX antenna gain (dBi)", dcc.Slider(
                        id="rx-gain-dbi", min=-5, max=15, step=1, value=2,
                        marks={-5: "-5", 0: "0", 10: "10", 15: "15"},
                        tooltip={"placement": "bottom", "always_visible": False},
                    )),
                ]),
                control_block("Attack antenna gain (dBi)", dcc.Slider(
                    id="jammer-gain-dbi", min=-5, max=20, step=1, value=5,
                    marks={-5: "-5", 0: "0", 10: "10", 20: "20"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
            ])
        ]),
        dcc.Tab(label="Geometry / Channel", value="tab-channel", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
            html.Div(style={"paddingTop": "12px"}, children=[
                control_block("Drone link distance (m)", dcc.Slider(
                    id="link-distance-m", min=5, max=150, step=1, value=40,
                    marks={5: "5", 50: "50", 100: "100", 150: "150"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Attack-source distance to receiver (m)", dcc.Slider(
                    id="attacker-distance-m", min=2, max=150, step=1, value=25,
                    marks={2: "2", 50: "50", 100: "100", 150: "150"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Path-loss exponent", dcc.Slider(
                    id="path-loss-exp", min=1.6, max=4.0, step=0.1, value=2.2,
                    marks={1.6: "1.6", 2.0: "2", 3.0: "3", 4.0: "4"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Receiver noise figure (dB)", dcc.Slider(
                    id="noise-figure-db", min=2, max=20, step=1, value=7,
                    marks={2: "2", 7: "7", 12: "12", 20: "20"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Background SNR limit (dB)", dcc.Slider(
                    id="snr-db", min=0, max=30, step=1, value=16,
                    marks={0: "0", 10: "10", 20: "20", 30: "30"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
            ])
        ]),
        dcc.Tab(label="Attack Waveform", value="tab-attack", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
            html.Div(style={"paddingTop": "12px"}, children=[
                control_block("J/S manual trim (dB)", dcc.Slider(
                    id="jsr-db", min=-20, max=20, step=1, value=0,
                    marks={-20: "-20", -10: "-10", 0: "0", 10: "10", 20: "20"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Jammer center offset (kHz, baseband view)", dcc.Slider(
                    id="jammer-center-khz", min=1, max=85, step=1, value=20,
                    marks={1: "1", 20: "20", 50: "50", 85: "85"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Sweep / barrage span (kHz)", dcc.Slider(
                    id="sweep-span-khz", min=5, max=160, step=5, value=80,
                    marks={5: "5", 40: "40", 80: "80", 160: "160"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                control_block("Pulse/intermittent/reactive duty cycle", dcc.Slider(
                    id="duty-cycle", min=0.05, max=1.0, step=0.05, value=0.35,
                    marks={0.05: "5%", 0.5: "50%", 1.0: "100%"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                html.Div(
                    "These are normalized baseband visualization controls for education, not operational radio settings.",
                    style={"fontSize": "12px", "lineHeight": "1.45", "color": "#4a5d7a"},
                ),
            ])
        ]),
        dcc.Tab(label="Navigation", value="tab-nav", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
            html.Div(style={"paddingTop": "12px"}, children=[
                control_block("GPS spoofing maximum bias (m)", dcc.Slider(
                    id="spoof-bias", min=0, max=35, step=1, value=18,
                    marks={0: "0", 10: "10", 20: "20", 35: "35"},
                    tooltip={"placement": "bottom", "always_visible": False},
                )),
                html.Div(
                    "The navigation layer compares true, GPS-like, VIO, TDoA, and fused trajectories. Countermeasures can reject inconsistent GPS-like data.",
                    style={"fontSize": "12px", "lineHeight": "1.45", "color": "#4a5d7a"},
                ),
            ])
        ]),
    ],
)


app.layout = html.Div(style=PAGE_STYLE, children=[
    dcc.Store(id="sim-state", data={"running": False, "live_index": 0}),
    dcc.Store(id="help-state", data={"enabled": True, "visible": False, "topic": "welcome"}),
    html.Div(style={"display": "flex", "justifyContent": "space-between", "alignItems": "flex-start", "gap": "20px"}, children=[
        html.Div(children=[
            html.H1("Drone Attack and Countermeasure Educational Simulator", style={"margin": "0", "color": "#243f7a"}),
            html.Div(
                "Tabbed controls for RF link budget, jamming waveforms, GPS spoofing, navigation fusion, defensive countermeasures, and emergent Help Mode windows.",
                style={"marginTop": "6px", "fontSize": "14px", "color": "#4a5d7a"},
            ),
        ]),
        html.Div(
            "No RF transmission • No hardware control • Defensive education only",
            style={"background": "#fff7e6", "border": "1px solid #ffd591", "borderRadius": "8px", "padding": "8px 10px", "fontWeight": "700", "fontSize": "12px"},
        ),
    ]),

    html.Div(
        id="run-bar",
        style={
            "display": "flex", "alignItems": "center", "justifyContent": "space-between",
            "gap": "10px", "background": "#eef5ff", "border": "1px solid #c8d6ea",
            "borderRadius": "10px", "padding": "10px", "marginTop": "16px", "marginBottom": "12px",
        },
        children=[
            html.Div(id="run-status", children=make_run_status({"running": False, "live_index": 0}, 750)),
            html.Div(style={"display": "flex", "gap": "8px"}, children=[
                html.Button("Start", id="btn-start", n_clicks=0, style={**BUTTON_STYLE, "background": "#d8f5dd", "color": "#176b2c"}),
                html.Button("Stop", id="btn-stop", n_clicks=0, style={**BUTTON_STYLE, "background": "#ffe3e3", "color": "#9f1d1d"}),
                html.Button("Reset", id="btn-reset", n_clicks=0, style={**BUTTON_STYLE, "background": "#fff1cc", "color": "#8a5a00"}),
                html.Button("Help Mode", id="btn-help-mode", n_clicks=0, style={**BUTTON_STYLE, "background": "#e8f0ff", "color": "#243f7a"}),
                html.Button("Quick Help", id="btn-help-welcome", n_clicks=0, style={**BUTTON_STYLE, "background": "#f3f8ff", "color": "#243f7a"}),
            ]),
        ],
    ),

    html.Div(style={"display": "grid", "gridTemplateColumns": "430px 1fr", "gap": "14px", "marginTop": "8px"}, children=[
        html.Div(style=PANEL_STYLE, children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between", "alignItems": "center", "gap": "8px"}, children=[
                html.H3("Control Panel", style={"marginTop": "0", "color": "#243f7a", "marginBottom": "6px"}),
                html.Div(id="help-mode-badge", style={"fontSize": "12px", "fontWeight": "700", "color": "#176b2c"}, children="Help Mode: ON"),
            ]),
            make_help_topic_buttons(),
            controls_tabs,
            html.Hr(),
            html.Div(
                "For book/teaching use: the model is qualitative and illustrates symptoms, metrics, and defensive responses.",
                style={"fontSize": "12px", "lineHeight": "1.45", "color": "#4a5d7a"},
            ),
        ]),

        html.Div(children=[
            html.Div(id="status-cards", style={"marginBottom": "12px"}),
            html.Div(style=PANEL_STYLE, children=[
                html.H3("Live Navigation Estimate Table", style={"marginTop": "0", "color": "#243f7a"}),
                html.Div(id="position-table"),
            ]),
        ]),
    ]),

    html.Div(style={"marginTop": "14px"}, children=[
        dcc.Tabs(id="scope-tabs", value="overview", children=[
            dcc.Tab(label="Overview", value="overview", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
                html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "14px", "paddingTop": "12px"}, children=[
                    figure_panel("fig-navigation", "Navigation / Sensor Fusion", help_topic="navigation"),
                    figure_panel("fig-summary", "Live Summary Metrics", help_topic="scopes"),
                    figure_panel("fig-metrics", "Mission Metrics", span=True, help_topic="mission"),
                ])
            ]),
            dcc.Tab(label="RF Scopes", value="rf", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
                html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "14px", "paddingTop": "12px"}, children=[
                    figure_panel("fig-waveforms", "Waveform Scope", help_topic="attack_waveform"),
                    figure_panel("fig-spectrum", "Spectrum Scope", help_topic="attack_waveform"),
                    figure_panel("fig-waterfall", "Waterfall Scope", span=True, help_topic="attack_waveform"),
                ])
            ]),
            dcc.Tab(label="Link Budget", value="budget", style=TAB_STYLE, selected_style=SELECTED_TAB_STYLE, children=[
                html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "14px", "paddingTop": "12px"}, children=[
                    figure_panel("fig-link-budget", "Link Budget Scope", help_topic="rf_link"),
                    html.Div(style=PANEL_STYLE, children=[
                        html.H3("Live RF Budget Table", style={"marginTop": "0", "color": "#243f7a"}),
                        html.Div(id="link-budget-table"),
                    ]),
                ])
            ]),
        ]),
    ]),

    make_help_modal(),

    dcc.Interval(id="interval", interval=750, n_intervals=0, disabled=True),
])


@app.callback(
    Output("help-mode-badge", "children"),
    Output("help-mode-badge", "style"),
    Output("help-modal", "style"),
    Output("help-modal-title", "children"),
    Output("help-modal-body", "children"),
    Output("help-state", "data"),
    Input("btn-help-mode", "n_clicks"),
    Input("btn-help-welcome", "n_clicks"),
    Input("btn-help-close", "n_clicks"),
    Input({"type": "help-topic", "topic": ALL}, "n_clicks"),
    State("help-state", "data"),
)
def update_help_mode(help_mode_clicks, welcome_clicks, close_clicks, topic_clicks, help_state):
    state = dict(help_state or {"enabled": True, "visible": False, "topic": "welcome"})
    state.setdefault("enabled", True)
    state.setdefault("visible", False)
    state.setdefault("topic", "welcome")

    triggered = callback_context.triggered_id
    if triggered == "btn-help-mode":
        state["enabled"] = not bool(state.get("enabled", True))
        state["visible"] = bool(state["enabled"])
        state["topic"] = "welcome"
    elif triggered == "btn-help-welcome":
        state["enabled"] = True
        state["visible"] = True
        state["topic"] = "welcome"
    elif triggered == "btn-help-close":
        state["visible"] = False
    elif isinstance(triggered, dict) and triggered.get("type") == "help-topic":
        # Help-topic buttons act as emergent windows. When Help Mode was off,
        # clicking a topic re-enables it so the user can still get assistance.
        state["enabled"] = True
        state["visible"] = True
        state["topic"] = triggered.get("topic", "welcome")

    topic = state.get("topic", "welcome")
    info = HELP_TOPICS.get(topic, HELP_TOPICS["welcome"])
    enabled = bool(state.get("enabled", True))
    visible = bool(state.get("visible", False)) and enabled
    badge_style = {
        "fontSize": "12px",
        "fontWeight": "700",
        "color": "#176b2c" if enabled else "#9f1d1d",
        "background": "#e8f8ed" if enabled else "#ffe3e3",
        "border": "1px solid #b9e5c4" if enabled else "1px solid #ffb5b5",
        "borderRadius": "999px",
        "padding": "5px 9px",
        "whiteSpace": "nowrap",
    }
    badge = "Help Mode: ON" if enabled else "Help Mode: OFF"
    return badge, badge_style, help_modal_style(visible), info["title"], make_help_body(topic), state


@app.callback(
    Output("fig-waveforms", "figure"),
    Output("fig-spectrum", "figure"),
    Output("fig-waterfall", "figure"),
    Output("fig-navigation", "figure"),
    Output("fig-metrics", "figure"),
    Output("fig-link-budget", "figure"),
    Output("fig-summary", "figure"),
    Output("status-cards", "children"),
    Output("position-table", "children"),
    Output("link-budget-table", "children"),
    Output("run-status", "children"),
    Output("interval", "interval"),
    Output("interval", "disabled"),
    Output("sim-state", "data"),
    Input("interval", "n_intervals"),
    Input("btn-start", "n_clicks"),
    Input("btn-stop", "n_clicks"),
    Input("btn-reset", "n_clicks"),
    Input("attack-type", "value"),
    Input("countermeasure", "value"),
    Input("jsr-db", "value"),
    Input("snr-db", "value"),
    Input("carrier-mhz", "value"),
    Input("signal-bandwidth-khz", "value"),
    Input("tx-power-dbm", "value"),
    Input("jammer-power-dbm", "value"),
    Input("tx-gain-dbi", "value"),
    Input("rx-gain-dbi", "value"),
    Input("jammer-gain-dbi", "value"),
    Input("link-distance-m", "value"),
    Input("attacker-distance-m", "value"),
    Input("path-loss-exp", "value"),
    Input("noise-figure-db", "value"),
    Input("jammer-center-khz", "value"),
    Input("sweep-span-khz", "value"),
    Input("duty-cycle", "value"),
    Input("spoof-bias", "value"),
    Input("update-ms", "value"),
    State("sim-state", "data"),
)
def update_dashboard_tabs(
    n_intervals: int,
    start_clicks: int,
    stop_clicks: int,
    reset_clicks: int,
    attack_type: str,
    countermeasure: str,
    jsr_db: float,
    snr_db: float,
    carrier_mhz: float,
    signal_bandwidth_khz: float,
    tx_power_dbm: float,
    jammer_power_dbm: float,
    tx_gain_dbi: float,
    rx_gain_dbi: float,
    jammer_gain_dbi: float,
    link_distance_m: float,
    attacker_distance_m: float,
    path_loss_exponent: float,
    noise_figure_db: float,
    jammer_center_khz: float,
    sweep_span_khz: float,
    duty_cycle: float,
    spoof_bias_m: float,
    update_ms: int,
    state: dict,
):
    state = dict(state or {"running": False, "live_index": 0})
    state.setdefault("running", False)
    state.setdefault("live_index", 0)

    triggered = callback_context.triggered[0]["prop_id"].split(".")[0] if callback_context.triggered else ""

    if triggered == "btn-start":
        state["running"] = True
    elif triggered == "btn-stop":
        state["running"] = False
    elif triggered == "btn-reset":
        state["running"] = False
        state["live_index"] = 0
    elif triggered == "interval" and state.get("running", False):
        state["live_index"] = int(state.get("live_index", 0)) + 1

    live_index = int(state.get("live_index", 0))
    update_ms = int(update_ms or 750)

    sim = run_simulation(
        attack_type=attack_type,
        countermeasure=countermeasure,
        jsr_db=float(jsr_db),
        snr_db=float(snr_db),
        duty_cycle=float(duty_cycle),
        spoof_bias_m=float(spoof_bias_m),
        live_index=live_index,
        carrier_mhz=float(carrier_mhz),
        signal_bandwidth_khz=float(signal_bandwidth_khz),
        tx_power_dbm=float(tx_power_dbm),
        jammer_power_dbm=float(jammer_power_dbm),
        tx_gain_dbi=float(tx_gain_dbi),
        rx_gain_dbi=float(rx_gain_dbi),
        jammer_gain_dbi=float(jammer_gain_dbi),
        link_distance_m=float(link_distance_m),
        attacker_distance_m=float(attacker_distance_m),
        path_loss_exponent=float(path_loss_exponent),
        noise_figure_db=float(noise_figure_db),
        jammer_center_khz=float(jammer_center_khz),
        sweep_span_khz=float(sweep_span_khz),
    )

    interval_disabled = not bool(state.get("running", False))

    return (
        fig_waveforms(sim),
        fig_spectrum(sim),
        fig_waterfall(sim),
        fig_navigation(sim),
        fig_metrics(sim),
        fig_link_budget(sim),
        fig_scope_summary(sim),
        make_status_cards(sim),
        make_position_table(sim),
        make_link_budget_table(sim),
        make_run_status(state, update_ms),
        update_ms,
        interval_disabled,
        state,
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8050, debug=False)
