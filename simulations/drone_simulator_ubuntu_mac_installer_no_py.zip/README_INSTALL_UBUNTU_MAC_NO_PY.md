# Drone Simulator Installer — Ubuntu and macOS

This package installs the **Drone Attack and Countermeasure Educational Simulator** with two modes:

- **Single Drone**
- **Swarm Drone** with updated status for each UAV

The Python simulator file is not exposed in the project folder. The installer writes it as a hidden application file in the user application directory and creates a launcher command.

## Ubuntu / Linux

```bash
chmod +x install_drone_simulator_ubuntu_mac.sh
./install_drone_simulator_ubuntu_mac.sh
```

Run:

```bash
drone-simulator
```

If the command is not found:

```bash
~/.local/bin/drone-simulator
```

## macOS

```bash
chmod +x install_drone_simulator_ubuntu_mac.sh
./install_drone_simulator_ubuntu_mac.sh
```

Run:

```bash
drone-simulator
```

If the command is not found:

```bash
~/.local/bin/drone-simulator
```

A **Drone Simulator.command** launcher is also created on the Desktop when possible.

## Browser

After launching, open:

```text
http://127.0.0.1:8050
```

## Requirements installed automatically

- Dash
- Plotly
- NumPy

The installer creates a local virtual environment, so it does not modify your global Python packages.

## Safety note

This is a safe educational simulator. It uses normalized numerical waveforms only. It does not transmit RF energy, control real drones, or provide operational hardware attack instructions.
